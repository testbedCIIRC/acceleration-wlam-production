"""
Optris (OTC SDK) -> NVIDIA Omniverse bridge
- Connects to an Optris PI/Xi camera over Ethernet (device sends UDP frames to host)
- Extracts: hotspot (max temp) + ROI temperatures (mean/min/max)
- Visualizes: live false-color image as an Omniverse DynamicTextureProvider (UI + optional plane in USD)

Tested conceptually against OTC SDK 10.x API docs (IRImager / IRImagerClient).
You may need to adjust the IRImager creation call depending on your binding entry point
(IRImagerFactory / IRImagerCreator methods differ slightly by language binding).
"""

import threading
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

# --- Optris OTC SDK ---
import optris.otcsdk as otc

# --- Omniverse / Kit ---
import omni.ui as ui
import omni.kit.app
import omni.usd
from pxr import Gf, Sdf, UsdGeom, UsdShade


# -----------------------------
# Helpers
# -----------------------------
def _get_enum_value(module, name: str):
    """Safely fetch an enum value from OTC SDK python bindings (often exposed as int constants)."""
    return getattr(module, name, None)


def temps_to_jet_rgba_u8(temps_c: np.ndarray, t_min: float, t_max: float) -> np.ndarray:
    """
    Map temperatures (°C) to an RGBA uint8 image using a simple 'jet-like' colormap.
    temps_c: (H, W) float32/float64
    returns: (H, W, 4) uint8
    """
    if t_max <= t_min:
        t_max = t_min + 1e-6

    x = (temps_c - t_min) / (t_max - t_min)
    x = np.clip(x, 0.0, 1.0)

    # Jet-like piecewise formula
    r = np.clip(1.5 - np.abs(4.0 * x - 3.0), 0.0, 1.0)
    g = np.clip(1.5 - np.abs(4.0 * x - 2.0), 0.0, 1.0)
    b = np.clip(1.5 - np.abs(4.0 * x - 1.0), 0.0, 1.0)
    a = np.ones_like(r)

    rgba = np.stack([r, g, b, a], axis=-1)
    return (rgba * 255.0).astype(np.uint8)


def clamp_roi(x0: int, y0: int, x1: int, y1: int, w: int, h: int) -> Tuple[int, int, int, int]:
    x0c = max(0, min(w, x0))
    x1c = max(0, min(w, x1))
    y0c = max(0, min(h, y0))
    y1c = max(0, min(h, y1))
    if x1c < x0c:
        x0c, x1c = x1c, x0c
    if y1c < y0c:
        y0c, y1c = y1c, y0c
    return x0c, y0c, x1c, y1c


# -----------------------------
# Data model
# -----------------------------
@dataclass
class RoiRect:
    name: str
    x0: int
    y0: int
    x1: int
    y1: int


@dataclass
class FrameMetrics:
    hotspot_xy: Tuple[int, int]
    hotspot_temp_c: float
    frame_min_c: float
    frame_max_c: float
    frame_mean_c: float
    roi_stats: Dict[str, Dict[str, float]]  # {roi_name: {"mean":..., "min":..., "max":...}}


# -----------------------------
# Optris client (receives frames)
# -----------------------------
class OptrisClient(otc.IRImagerClient):
    def __init__(self, rois: List[RoiRect], auto_color_range: bool = True, fixed_range: Tuple[float, float] = (20.0, 80.0)):
        super().__init__()
        self._lock = threading.Lock()

        self._w: int = 0
        self._h: int = 0
        self._rois = rois

        self._auto_color_range = auto_color_range
        self._fixed_range = fixed_range

        self._temps_1d: Optional[np.ndarray] = None  # float32, length w*h
        self._rgba: Optional[np.ndarray] = None      # uint8, shape (h,w,4)
        self._metrics: Optional[FrameMetrics] = None
        self._new_frame: bool = False
        self._status: str = "Waiting for frames..."

        self._FLAG_INITIALIZING = _get_enum_value(otc, "FlagState_Initializing")

    def _ensure_buffers(self, w: int, h: int):
        if w <= 0 or h <= 0:
            return
        if self._temps_1d is None or self._w != w or self._h != h:
            self._w, self._h = w, h
            self._temps_1d = np.zeros((w * h,), dtype=np.float32)
            self._rgba = np.zeros((h, w, 4), dtype=np.uint8)

    # Called when connect() or setActiveOperationMode() changes format
    def onVideoFormatChanged(self, width: int, height: int, framerate: float, bitCount: int):
        with self._lock:
            self._ensure_buffers(width, height)
            self._status = f"VideoFormat: {width}x{height} @ {framerate:.1f} Hz, {bitCount} bit"

    # Main thermal callback
    def onThermalFrame(self, thermal: "otc.ThermalFrame", meta: "otc.FrameMetadata"):
        # Skip frames during startup calibration (unreliable temperatures)
        try:
            if self._FLAG_INITIALIZING is not None and meta.getFlagState() == self._FLAG_INITIALIZING:
                return
        except Exception:
            # If flag state isn't available for some reason, proceed (best-effort)
            pass

        # Determine frame size
        w = self._w
        h = self._h
        if hasattr(thermal, "getWidth") and hasattr(thermal, "getHeight"):
            try:
                w = int(thermal.getWidth())
                h = int(thermal.getHeight())
            except Exception:
                pass

        with self._lock:
            self._ensure_buffers(w, h)
            if self._temps_1d is None:
                return

            # Copy temperatures in °C into the preallocated array (OTC SDK 10.x)
            thermal.copyTemperaturesTo(self._temps_1d)

            temps2d = self._temps_1d.reshape((h, w))

            # Global stats + hotspot
            frame_min = float(np.min(temps2d))
            frame_max = float(np.max(temps2d))
            frame_mean = float(np.mean(temps2d))

            max_idx = int(np.argmax(temps2d))
            hy, hx = divmod(max_idx, w)
            hotspot_temp = float(temps2d[hy, hx])

            # ROI stats
            roi_stats: Dict[str, Dict[str, float]] = {}
            for roi in self._rois:
                x0, y0, x1, y1 = clamp_roi(roi.x0, roi.y0, roi.x1, roi.y1, w, h)
                if (x1 - x0) <= 0 or (y1 - y0) <= 0:
                    roi_stats[roi.name] = {"mean": float("nan"), "min": float("nan"), "max": float("nan")}
                    continue
                patch = temps2d[y0:y1, x0:x1]
                roi_stats[roi.name] = {
                    "mean": float(np.mean(patch)),
                    "min": float(np.min(patch)),
                    "max": float(np.max(patch)),
                }

            # Color mapping range
            if self._auto_color_range:
                t_min, t_max = frame_min, frame_max
            else:
                t_min, t_max = self._fixed_range

            # Build RGBA
            self._rgba = temps_to_jet_rgba_u8(temps2d, t_min=t_min, t_max=t_max)

            self._metrics = FrameMetrics(
                hotspot_xy=(hx, hy),
                hotspot_temp_c=hotspot_temp,
                frame_min_c=frame_min,
                frame_max_c=frame_max,
                frame_mean_c=frame_mean,
                roi_stats=roi_stats,
            )
            self._new_frame = True

    def onConnectionTimeout(self):
        # For Ethernet devices, timeouts are the mechanism to detect stream loss
        with self._lock:
            self._status = "⚠ Connection timeout (no UDP frames received)."

    def onConnectionLost(self):
        # Mostly relevant for USB, but provided for completeness
        with self._lock:
            self._status = "✖ Connection lost."

    # Called by Omniverse update loop
    def pop_latest(self) -> Tuple[Optional[np.ndarray], Optional[FrameMetrics], str, bool]:
        with self._lock:
            rgba = None if self._rgba is None else self._rgba.copy()
            metrics = self._metrics
            status = self._status
            new = self._new_frame
            self._new_frame = False
            return rgba, metrics, status, new


# -----------------------------
# IRImager creation (factory/creator differences)
# -----------------------------
def create_ir_imager() -> "otc.IRImager":
    """
    IRImager is an interface; the SDK provides a factory/creator to instantiate it.
    This helper tries common entry points across bindings/versions.
    """
    # Common: IRImagerFactory.<something>()
    factory = getattr(otc, "IRImagerFactory", None)
    if factory is not None:
        for meth in ("create", "createImager", "createIRImager", "createInstance", "instance"):
            fn = getattr(factory, meth, None)
            if callable(fn):
                try:
                    return fn()
                except TypeError:
                    pass

    # Common: IRImagerCreator.<something>()
    creator = getattr(otc, "IRImagerCreator", None)
    if creator is not None:
        for meth in ("create", "createImager", "createIRImager", "createInstance", "instance"):
            fn = getattr(creator, meth, None)
            if callable(fn):
                return fn()

    # Fallback (some bindings may expose a concrete IRImager directly)
    try:
        return otc.IRImager()
    except Exception as e:
        raise RuntimeError(
            "Could not create IRImager. Check your OTC SDK Python binding for IRImagerFactory/IRImagerCreator methods."
        ) from e


# -----------------------------
# Omniverse bridge (UI + optional plane)
# -----------------------------
class OptrisOmniverseBridge:
    def __init__(
        self,
        network_cidr: str,
        serial_number: int,
        rois: List[RoiRect],
        texture_name: str = "optris_thermal_tex",
        plane_path: str = "/World/OptrisThermalPlane",
        create_plane: bool = True,
    ):
        self._network_cidr = network_cidr
        self._serial = serial_number
        self._rois = rois

        self._texture_name = texture_name
        self._plane_path = plane_path
        self._create_plane = create_plane

        self._client = OptrisClient(rois=rois, auto_color_range=True)
        self._imager = None

        self._tex_provider = ui.DynamicTextureProvider(self._texture_name)
        self._window = None
        self._labels = {}
        self._update_sub = None

    def _ensure_plane_and_material(self):
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return

        # Create a simple quad mesh (plane) if it doesn't exist
        prim = stage.GetPrimAtPath(self._plane_path)
        if not prim.IsValid():
            mesh = UsdGeom.Mesh.Define(stage, self._plane_path)
            # Quad in X-Z plane
            points = [Gf.Vec3f(-0.5, 0.0, -0.5), Gf.Vec3f(0.5, 0.0, -0.5), Gf.Vec3f(0.5, 0.0, 0.5), Gf.Vec3f(-0.5, 0.0, 0.5)]
            mesh.CreatePointsAttr(points)
            mesh.CreateFaceVertexCountsAttr([4])
            mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])

            # UVs (st)
            pv = UsdGeom.PrimvarsAPI(mesh)
            st = pv.CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.varying)
            st.Set([Gf.Vec2f(0.0, 0.0), Gf.Vec2f(1.0, 0.0), Gf.Vec2f(1.0, 1.0), Gf.Vec2f(0.0, 1.0)])

        # Create/Bind OmniPBR with dynamic texture
        material_path = f"{self._plane_path}/Material"
        shader_path = f"{material_path}/Shader"

        material = UsdShade.Material.Define(stage, material_path)
        shader = UsdShade.Shader.Define(stage, shader_path)

        shader.SetSourceAsset("OmniPBR.mdl", "mdl")
        shader.SetSourceAssetSubIdentifier("OmniPBR", "mdl")
        shader.CreateIdAttr("OmniPBR")

        # Dynamic texture URI
        shader.CreateInput("diffuse_texture", Sdf.ValueTypeNames.Asset).Set(f"dynamic://{self._texture_name}")

        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")

        plane_prim = stage.GetPrimAtPath(self._plane_path)
        UsdShade.MaterialBindingAPI.Apply(plane_prim)
        UsdShade.MaterialBindingAPI(plane_prim).Bind(material)

    def _build_ui(self):
        self._window = ui.Window("Optris Thermal Stream", width=520, height=720)
        with self._window.frame:
            with ui.VStack(spacing=6):
                self._labels["status"] = ui.Label("Status: (starting...)")
                self._labels["hotspot"] = ui.Label("Hotspot: -")
                self._labels["frame"] = ui.Label("Frame: -")
                ui.Separator()

                for roi in self._rois:
                    self._labels[f"roi:{roi.name}"] = ui.Label(f"{roi.name}: -")

                ui.Separator()
                ui.Label("Thermal image (false color):")
                ui.ImageWithProvider(self._tex_provider, height=480)

    def start(self):
        # 1) Configure detection for Ethernet subnet
        enum_mgr = otc.EnumerationManager.getInstance()
        enum_mgr.addEthernetDetector(self._network_cidr)

        # 2) Create IRImager
        self._imager = create_ir_imager()

        # 3) Register client BEFORE connect (so format callback can be delivered)
        self._imager.addClient(self._client)

        # 4) Connect (serial=0 => first available)
        self._imager.connect(int(self._serial))

        # 5) Run processing loop in SDK thread so Omniverse UI stays responsive
        ok = self._imager.runAsync()
        if not ok:
            raise RuntimeError("IRImager.runAsync() failed to start within timeout")

        # 6) Omniverse UI + optional plane
        self._build_ui()
        if self._create_plane:
            self._ensure_plane_and_material()

        # 7) Subscribe to Omniverse update loop to push new textures safely on main thread
        app = omni.kit.app.get_app()
        self._update_sub = app.get_update_event_stream().create_subscription_to_pop(self._on_update)

    def stop(self):
        if self._update_sub is not None:
            self._update_sub = None

        if self._imager is not None:
            try:
                if self._imager.isRunning():
                    self._imager.stopRunning()
            except Exception:
                pass
            try:
                if self._imager.isConnected():
                    self._imager.disconnect()
            except Exception:
                pass
            self._imager = None

        self._window = None

    def _on_update(self, *_):
        rgba, metrics, status, new = self._client.pop_latest()

        # Always update status label
        if self._window is not None and "status" in self._labels:
            self._labels["status"].text = f"Status: {status}"

        # Only push texture/metrics when a new frame arrived
        if not new or rgba is None or metrics is None:
            return

        h, w, _ = rgba.shape
        # set_data_array expects uint8 array + sizes as (width, height)
        self._tex_provider.set_data_array(rgba.reshape(-1), [w, h])

        self._labels["hotspot"].text = f"Hotspot: (x={metrics.hotspot_xy[0]}, y={metrics.hotspot_xy[1]}), {metrics.hotspot_temp_c:.2f} °C"
        self._labels["frame"].text = f"Frame: mean={metrics.frame_mean_c:.2f} °C | min={metrics.frame_min_c:.2f} °C | max={metrics.frame_max_c:.2f} °C"

        for roi in self._rois:
            s = metrics.roi_stats.get(roi.name, {})
            self._labels[f"roi:{roi.name}"].text = (
                f"{roi.name}: mean={s.get('mean', float('nan')):.2f} °C | "
                f"min={s.get('min', float('nan')):.2f} °C | "
                f"max={s.get('max', float('nan')):.2f} °C"
            )


# -----------------------------
# Configure & run
# -----------------------------
NETWORK_CIDR = "192.168.0.0/24"  # <-- change to your camera subnet
SERIAL = 0                      # 0 = first available device
ROIS = [
    RoiRect("Center 40x40", x0=140, y0=100, x1=180, y1=140),
    RoiRect("TopLeft 50x50", x0=10, y0=10, x1=60, y1=60),
]

# Keep a global reference so it doesn't get garbage-collected
optris_bridge = OptrisOmniverseBridge(
    network_cidr=NETWORK_CIDR,
    serial_number=SERIAL,
    rois=ROIS,
    texture_name="optris_thermal_tex",
    plane_path="/World/OptrisThermalPlane",
    create_plane=True,   # set False if you only want UI
)

# Start streaming
optris_bridge.start()

# To stop later, run:
# optris_bridge.stop()
